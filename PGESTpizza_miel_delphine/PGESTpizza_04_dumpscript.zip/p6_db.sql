
CREATE SEQUENCE public.status_id_status_seq;

CREATE TABLE public.status (
                id_status INTEGER NOT NULL DEFAULT nextval('public.status_id_status_seq'),
                advanced VARCHAR(50) NOT NULL,
                CONSTRAINT status_pk PRIMARY KEY (id_status)
);


ALTER SEQUENCE public.status_id_status_seq OWNED BY public.status.id_status;

CREATE UNIQUE INDEX status_idx
 ON public.status
 ( advanced );

CREATE SEQUENCE public.category_id_cat_seq;

CREATE TABLE public.category (
                id_cat INTEGER NOT NULL DEFAULT nextval('public.category_id_cat_seq'),
                name VARCHAR(50) NOT NULL,
                CONSTRAINT category_pk PRIMARY KEY (id_cat)
);


ALTER SEQUENCE public.category_id_cat_seq OWNED BY public.category.id_cat;

CREATE UNIQUE INDEX category_idx
 ON public.category
 ( name );

CREATE SEQUENCE public.product_product_ref_seq;

CREATE TABLE public.product (
                product_ref INTEGER NOT NULL DEFAULT nextval('public.product_product_ref_seq'),
                price NUMERIC NOT NULL,
                name VARCHAR(100) NOT NULL,
                id_cat INTEGER NOT NULL,
                CONSTRAINT product_pk PRIMARY KEY (product_ref)
);
COMMENT ON COLUMN public.product.price IS 'euros';


ALTER SEQUENCE public.product_product_ref_seq OWNED BY public.product.product_ref;

CREATE UNIQUE INDEX product_idx
 ON public.product
 ( name );

CREATE SEQUENCE public.ingredient_ref_prod_seq;

CREATE TABLE public.ingredient (
                id_ref INTEGER NOT NULL DEFAULT nextval('public.ingredient_ref_prod_seq'),
                name VARCHAR(80) NOT NULL,
                expire_date DATE NOT NULL,
                entering_date DATE NOT NULL,
                CONSTRAINT ingredient_pk PRIMARY KEY (id_ref)
);


ALTER SEQUENCE public.ingredient_ref_prod_seq OWNED BY public.ingredient.id_ref;

CREATE UNIQUE INDEX ingredient_idx
 ON public.ingredient
 ( name );

CREATE SEQUENCE public.recipe_id_seq;

CREATE TABLE public.recipe (
                id INTEGER NOT NULL DEFAULT nextval('public.recipe_id_seq'),
                name VARCHAR(100) NOT NULL,
                quantity INTEGER NOT NULL,
                id_ingredient INTEGER NOT NULL,
                product_ref INTEGER NOT NULL,
                CONSTRAINT recipe_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.recipe_id_seq OWNED BY public.recipe.id;

CREATE SEQUENCE public.role_id_job_seq;

CREATE TABLE public.role (
                id_job INTEGER NOT NULL DEFAULT nextval('public.role_id_job_seq'),
                job_status VARCHAR(80) NOT NULL,
                CONSTRAINT role_pk PRIMARY KEY (id_job)
);


ALTER SEQUENCE public.role_id_job_seq OWNED BY public.role.id_job;

CREATE UNIQUE INDEX role_idx
 ON public.role
 ( job_status );

CREATE SEQUENCE public.customer_num_client_seq;

CREATE TABLE public.customer (
                num_client INTEGER NOT NULL DEFAULT nextval('public.customer_num_client_seq'),
                surname VARCHAR(100) NOT NULL,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(50) NOT NULL,
                password VARCHAR(20) NOT NULL,
                phone VARCHAR(20),
                CONSTRAINT num_client_pk PRIMARY KEY (num_client)
);


ALTER SEQUENCE public.customer_num_client_seq OWNED BY public.customer.num_client;

CREATE SEQUENCE public.address_id_seq;

CREATE TABLE public.address (
                id INTEGER NOT NULL DEFAULT nextval('public.address_id_seq'),
                street VARCHAR(100) NOT NULL,
                zip_code VARCHAR(5) NOT NULL,
                city VARCHAR(50) NOT NULL,
                num_client INTEGER NOT NULL,
                CONSTRAINT address_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.address_id_seq OWNED BY public.address.id;

CREATE SEQUENCE public.restaurant_id_seq;

CREATE TABLE public.restaurant (
                id INTEGER NOT NULL DEFAULT nextval('public.restaurant_id_seq'),
                id_address INTEGER NOT NULL,
                name VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                email VARCHAR(50) NOT NULL,
                CONSTRAINT resto_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.restaurant_id_seq OWNED BY public.restaurant.id;

CREATE UNIQUE INDEX restaurant_idx
 ON public.restaurant
 ( name );

CREATE SEQUENCE public.stock_reference_seq;

CREATE TABLE public.stock (
                reference INTEGER NOT NULL DEFAULT nextval('public.stock_reference_seq'),
                quantity INTEGER NOT NULL,
                unit VARCHAR(5) NOT NULL,
                id_resto INTEGER NOT NULL,
                id_ingredient INTEGER NOT NULL,
                CONSTRAINT stock_pk PRIMARY KEY (reference)
);
COMMENT ON COLUMN public.stock.unit IS 'Kg or L';


ALTER SEQUENCE public.stock_reference_seq OWNED BY public.stock.reference;

CREATE SEQUENCE public.employee_id_seq;

CREATE TABLE public.employee (
                id INTEGER NOT NULL DEFAULT nextval('public.employee_id_seq'),
                surname VARCHAR(100) NOT NULL,
                name VARCHAR(100) NOT NULL,
                id_address INTEGER NOT NULL,
                id_resto INTEGER NOT NULL,
                id_job INTEGER NOT NULL,
                CONSTRAINT employee_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;

CREATE SEQUENCE public.order_client_number_seq;

CREATE TABLE public.order_client (
                oder_num INTEGER NOT NULL DEFAULT nextval('public.order_client_number_seq'),
                price NUMERIC NOT NULL,
                order_date TIMESTAMP NOT NULL,
                id_employee INTEGER NOT NULL,
                id_address INTEGER NOT NULL,
                num_client INTEGER NOT NULL,
                id_status INTEGER NOT NULL,
                id_resto INTEGER NOT NULL,
                CONSTRAINT order_client_pk PRIMARY KEY (oder_num)
);
COMMENT ON COLUMN public.order_client.price IS 'euros';


ALTER SEQUENCE public.order_client_number_seq OWNED BY public.order_client.oder_num;

CREATE UNIQUE INDEX order_idx
 ON public.order_client
 ( oder_num );

CREATE UNIQUE INDEX order_idx1
 ON public.order_client
 ( oder_num );

CREATE SEQUENCE public.order_line_quantity_seq;

CREATE TABLE public.order_line (
                quantity INTEGER NOT NULL DEFAULT nextval('public.order_line_quantity_seq'),
                oder_num INTEGER NOT NULL,
                product_ref INTEGER NOT NULL,
                CONSTRAINT order_line_pk PRIMARY KEY (quantity)
);


ALTER SEQUENCE public.order_line_quantity_seq OWNED BY public.order_line.quantity;

ALTER TABLE public.order_client ADD CONSTRAINT status_order_fk
FOREIGN KEY (id_status)
REFERENCES public.status (id_status)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.product ADD CONSTRAINT category_product_fk
FOREIGN KEY (id_cat)
REFERENCES public.category (id_cat)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_line ADD CONSTRAINT product_order_line_fk
FOREIGN KEY (product_ref)
REFERENCES public.product (product_ref)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.recipe ADD CONSTRAINT product_recipe_fk
FOREIGN KEY (product_ref)
REFERENCES public.product (product_ref)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock ADD CONSTRAINT ingredient_stock_fk
FOREIGN KEY (id_ingredient)
REFERENCES public.ingredient (id_ref)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.recipe ADD CONSTRAINT ingredient_recipe_fk
FOREIGN KEY (id_ingredient)
REFERENCES public.ingredient (id_ref)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.employee ADD CONSTRAINT role_employee_fk
FOREIGN KEY (id_job)
REFERENCES public.role (id_job)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_client ADD CONSTRAINT customer_order_fk
FOREIGN KEY (num_client)
REFERENCES public.customer (num_client)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.address ADD CONSTRAINT customer_address_fk
FOREIGN KEY (num_client)
REFERENCES public.customer (num_client)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.restaurant ADD CONSTRAINT address_restaurant_fk
FOREIGN KEY (id_address)
REFERENCES public.address (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.employee ADD CONSTRAINT address_employee_fk
FOREIGN KEY (id_address)
REFERENCES public.address (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_client ADD CONSTRAINT address_order_fk
FOREIGN KEY (id_address)
REFERENCES public.address (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.employee ADD CONSTRAINT restaurant_employee_fk
FOREIGN KEY (id_resto)
REFERENCES public.restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock ADD CONSTRAINT restaurant_stock_fk
FOREIGN KEY (id_resto)
REFERENCES public.restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_client ADD CONSTRAINT restaurant_order_client_fk
FOREIGN KEY (id_resto)
REFERENCES public.restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_client ADD CONSTRAINT employee_order_fk
FOREIGN KEY (id_employee)
REFERENCES public.employee (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_line ADD CONSTRAINT order_order_line_fk
FOREIGN KEY (oder_num)
REFERENCES public.order_client (oder_num)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;
