--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id integer NOT NULL,
    street character varying(100) NOT NULL,
    zip_code character varying(5) NOT NULL,
    city character varying(50) NOT NULL,
    num_client integer
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_id_seq OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_id_seq OWNED BY public.address.id;


--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    id_cat integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: category_id_cat_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_id_cat_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_cat_seq OWNER TO postgres;

--
-- Name: category_id_cat_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_id_cat_seq OWNED BY public.category.id_cat;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    num_client integer NOT NULL,
    surname character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(50) NOT NULL,
    password character varying(20) NOT NULL,
    phone character varying(20)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_num_client_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_num_client_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_num_client_seq OWNER TO postgres;

--
-- Name: customer_num_client_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_num_client_seq OWNED BY public.customer.num_client;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    surname character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    id_address integer NOT NULL,
    id_resto integer NOT NULL,
    id_job integer NOT NULL
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_id_seq OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: ingredient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredient (
    id_ref integer NOT NULL,
    name character varying(80) NOT NULL,
    expire_date date NOT NULL,
    entering_date date NOT NULL
);


ALTER TABLE public.ingredient OWNER TO postgres;

--
-- Name: ingredient_ref_prod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingredient_ref_prod_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingredient_ref_prod_seq OWNER TO postgres;

--
-- Name: ingredient_ref_prod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingredient_ref_prod_seq OWNED BY public.ingredient.id_ref;


--
-- Name: order_client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_client (
    oder_num integer NOT NULL,
    price numeric NOT NULL,
    order_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_employee integer NOT NULL,
    id_address integer NOT NULL,
    num_client integer NOT NULL,
    id_status integer NOT NULL,
    id_resto integer NOT NULL
);


ALTER TABLE public.order_client OWNER TO postgres;

--
-- Name: COLUMN order_client.price; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.order_client.price IS 'euros';


--
-- Name: order_client_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_client_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_client_number_seq OWNER TO postgres;

--
-- Name: order_client_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_client_number_seq OWNED BY public.order_client.oder_num;


--
-- Name: order_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_line (
    order_num integer NOT NULL,
    product_ref integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.order_line OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_ref integer NOT NULL,
    price numeric NOT NULL,
    name character varying(100) NOT NULL,
    id_cat integer NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: COLUMN product.price; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.product.price IS 'euros';


--
-- Name: product_product_ref_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_product_ref_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_product_ref_seq OWNER TO postgres;

--
-- Name: product_product_ref_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_product_ref_seq OWNED BY public.product.product_ref;


--
-- Name: recipe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipe (
    id integer NOT NULL,
    quantity integer NOT NULL,
    id_ingredient integer NOT NULL,
    product_ref integer NOT NULL
);


ALTER TABLE public.recipe OWNER TO postgres;

--
-- Name: recipe_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recipe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recipe_id_seq OWNER TO postgres;

--
-- Name: recipe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recipe_id_seq OWNED BY public.recipe.id;


--
-- Name: restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant (
    id integer NOT NULL,
    id_address integer NOT NULL,
    name character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(50) NOT NULL
);


ALTER TABLE public.restaurant OWNER TO postgres;

--
-- Name: restaurant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.restaurant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.restaurant_id_seq OWNER TO postgres;

--
-- Name: restaurant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.restaurant_id_seq OWNED BY public.restaurant.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    id_job integer NOT NULL,
    job_status character varying(80) NOT NULL
);


ALTER TABLE public.role OWNER TO postgres;

--
-- Name: role_id_job_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_id_job_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_job_seq OWNER TO postgres;

--
-- Name: role_id_job_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_id_job_seq OWNED BY public.role.id_job;


--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    id_status integer NOT NULL,
    advanced character varying(50) NOT NULL
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: status_id_status_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_id_status_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_id_status_seq OWNER TO postgres;

--
-- Name: status_id_status_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_id_status_seq OWNED BY public.status.id_status;


--
-- Name: stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock (
    reference integer NOT NULL,
    quantity integer NOT NULL,
    unit character varying(5) NOT NULL,
    id_resto integer NOT NULL,
    id_ingredient integer NOT NULL
);


ALTER TABLE public.stock OWNER TO postgres;

--
-- Name: COLUMN stock.unit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.stock.unit IS 'g, cl, unit';


--
-- Name: stock_reference_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_reference_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_reference_seq OWNER TO postgres;

--
-- Name: stock_reference_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_reference_seq OWNED BY public.stock.reference;


--
-- Name: address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN id SET DEFAULT nextval('public.address_id_seq'::regclass);


--
-- Name: category id_cat; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category ALTER COLUMN id_cat SET DEFAULT nextval('public.category_id_cat_seq'::regclass);


--
-- Name: customer num_client; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN num_client SET DEFAULT nextval('public.customer_num_client_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: ingredient id_ref; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient ALTER COLUMN id_ref SET DEFAULT nextval('public.ingredient_ref_prod_seq'::regclass);


--
-- Name: order_client oder_num; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client ALTER COLUMN oder_num SET DEFAULT nextval('public.order_client_number_seq'::regclass);


--
-- Name: product product_ref; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN product_ref SET DEFAULT nextval('public.product_product_ref_seq'::regclass);


--
-- Name: recipe id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe ALTER COLUMN id SET DEFAULT nextval('public.recipe_id_seq'::regclass);


--
-- Name: restaurant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant ALTER COLUMN id SET DEFAULT nextval('public.restaurant_id_seq'::regclass);


--
-- Name: role id_job; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role ALTER COLUMN id_job SET DEFAULT nextval('public.role_id_job_seq'::regclass);


--
-- Name: status id_status; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status ALTER COLUMN id_status SET DEFAULT nextval('public.status_id_status_seq'::regclass);


--
-- Name: stock reference; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock ALTER COLUMN reference SET DEFAULT nextval('public.stock_reference_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (1, '12 rue des champignons', '86000', 'Poitiers', 1);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (2, '5 avenue du doberman', '86180', 'Buxerolles', 2);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (3, '225b avenue jean-pignon', '86360', 'Montamisé', 3);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (4, '3 impasse du vent', '86000', 'Poitiers', 4);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (6, '25 rue des savons', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (7, '7a avenue du golden', '86180', 'Buxerolles', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (8, '2 avenue raoul', '86360', 'Montamisé', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (9, '99 impasse du soleil', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (10, '1 rue des fouches', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (11, '18 avenue du bol', '86180', 'Buxerolles', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (12, '10 avenue cuillère', '86360', 'Montamisé', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (13, '5 impasse du serviette', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (14, '3b rue des assiettes', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (15, '9b avenue du jambono', '86180', 'Buxerolles', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (16, '3a avenue tsétsé', '86360', 'Montamisé', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (17, '9 impasse du bide', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (18, '299 rue du gras', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (19, '7c avenue du mouchoire', '86180', 'Buxerolles', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (20, '69 avenue stylo', '86360', 'Montamisé', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (21, '96 impasse du cornichon', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (22, '88 rue des olives', '86000', 'Poitiers', NULL);
INSERT INTO public.address (id, street, zip_code, city, num_client) VALUES (23, '18 impasse du roti', '86000', 'Poitiers', NULL);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.category (id_cat, name) VALUES (1, 'pizza');
INSERT INTO public.category (id_cat, name) VALUES (3, 'dessert');
INSERT INTO public.category (id_cat, name) VALUES (2, 'boisson');


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.customer (num_client, surname, name, email, password, phone) VALUES (1, 'Boby', 'Lewis', 'bob27@fakeemail.com', '0000', '5040302010');
INSERT INTO public.customer (num_client, surname, name, email, password, phone) VALUES (2, 'Alphonse', 'Dupont', 'fonfon@fakeemail.com', '0101', '0150024003');
INSERT INTO public.customer (num_client, surname, name, email, password, phone) VALUES (3, 'Arthur', 'jacquin', 'tutur@fakeemail.com', '1234', '1122334455');
INSERT INTO public.customer (num_client, surname, name, email, password, phone) VALUES (4, 'Lisa', 'paquerette', 'lisapak@fakeemail.com', '0077', '5544332211');


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (1, 'Duschmol', 'Frank', 10, 5, 1);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (2, 'Duschmol', 'Lola', 10, 5, 1);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (3, 'Martin', 'Raven', 11, 5, 2);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (4, 'Bambin', 'Sylvie', 12, 6, 2);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (5, 'Folle', 'Julien', 13, 7, 2);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (6, 'Biztu', 'Sylvain', 14, 8, 2);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (7, 'Schwarzi', 'Lucile', 15, 5, 3);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (8, 'Peninon', 'Louise', 16, 6, 3);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (9, 'Schok', 'Nico', 17, 7, 3);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (10, 'Astra', 'Kevin', 18, 8, 3);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (11, 'Fanfan', 'Charles', 19, 5, 4);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (12, 'Bidon', 'Maho', 20, 6, 4);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (13, 'Artus', 'Owen', 21, 7, 4);
INSERT INTO public.employee (id, surname, name, id_address, id_resto, id_job) VALUES (14, 'Doll', 'Aaron', 22, 8, 4);


--
-- Data for Name: ingredient; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ingredient (id_ref, name, expire_date, entering_date) VALUES (1, 'pâtes à pizza', '2020-12-31', '2020-12-05');
INSERT INTO public.ingredient (id_ref, name, expire_date, entering_date) VALUES (2, 'sauce tomate', '2020-01-10', '2020-12-05');
INSERT INTO public.ingredient (id_ref, name, expire_date, entering_date) VALUES (3, 'jambon', '2020-12-25', '2020-12-05');
INSERT INTO public.ingredient (id_ref, name, expire_date, entering_date) VALUES (4, 'mozzarella', '2020-12-15', '2020-12-05');
INSERT INTO public.ingredient (id_ref, name, expire_date, entering_date) VALUES (5, 'champignon', '2020-12-10', '2020-12-05');


--
-- Data for Name: order_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.order_client (oder_num, price, order_date, id_employee, id_address, num_client, id_status, id_resto) VALUES (1, 11.50, '2020-12-03 19:27:05', 7, 1, 1, 2, 5);
INSERT INTO public.order_client (oder_num, price, order_date, id_employee, id_address, num_client, id_status, id_resto) VALUES (2, 33.00, '2020-12-03 18:15:08', 12, 2, 2, 5, 6);


--
-- Data for Name: order_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.order_line (order_num, product_ref, quantity) VALUES (1, 1, 1);
INSERT INTO public.order_line (order_num, product_ref, quantity) VALUES (1, 3, 1);
INSERT INTO public.order_line (order_num, product_ref, quantity) VALUES (2, 1, 2);
INSERT INTO public.order_line (order_num, product_ref, quantity) VALUES (2, 3, 2);
INSERT INTO public.order_line (order_num, product_ref, quantity) VALUES (2, 5, 2);


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.product (product_ref, price, name, id_cat) VALUES (1, 9.50, 'Margherita', 1);
INSERT INTO public.product (product_ref, price, name, id_cat) VALUES (2, 12.50, 'jambon champignon', 1);
INSERT INTO public.product (product_ref, price, name, id_cat) VALUES (3, 2.00, 'Coca-Cola', 2);
INSERT INTO public.product (product_ref, price, name, id_cat) VALUES (4, 2.00, 'ice tea', 2);
INSERT INTO public.product (product_ref, price, name, id_cat) VALUES (5, 5.00, 'brownie', 3);
INSERT INTO public.product (product_ref, price, name, id_cat) VALUES (6, 5.80, 'glace chocolat', 3);


--
-- Data for Name: recipe; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (1, 1, 1, 1);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (2, 150, 2, 1);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (3, 1, 4, 1);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (4, 1, 1, 2);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (5, 150, 2, 2);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (6, 80, 3, 2);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (7, 1, 4, 2);
INSERT INTO public.recipe (id, quantity, id_ingredient, product_ref) VALUES (8, 60, 5, 2);


--
-- Data for Name: restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.restaurant (id, id_address, name, phone, email) VALUES (5, 9, 'OC Pizza Poit86', '0549562005', 'ocpizzapoit86@fakeemail.com');
INSERT INTO public.restaurant (id, id_address, name, phone, email) VALUES (6, 6, 'OC Pizza BuxGo', '0549562006', 'ocpizzabuxgo@fakeemail.com');
INSERT INTO public.restaurant (id, id_address, name, phone, email) VALUES (7, 7, 'OC Pizza MontGo', '0549562007', 'ocpizzamontgo@fakeemail.com');
INSERT INTO public.restaurant (id, id_address, name, phone, email) VALUES (8, 8, 'OC Pizza PoitGO', '0549562008', 'ocpizzapoitgo@fakeemail.com');


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.role (id_job, job_status) VALUES (1, 'Directeur');
INSERT INTO public.role (id_job, job_status) VALUES (2, 'Manager');
INSERT INTO public.role (id_job, job_status) VALUES (3, 'pizzaiolo');
INSERT INTO public.role (id_job, job_status) VALUES (4, 'livreur');


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.status (id_status, advanced) VALUES (1, 'en attente');
INSERT INTO public.status (id_status, advanced) VALUES (2, 'En préparation');
INSERT INTO public.status (id_status, advanced) VALUES (3, 'Prête');
INSERT INTO public.status (id_status, advanced) VALUES (4, 'En livraison');
INSERT INTO public.status (id_status, advanced) VALUES (5, 'Livrée');
INSERT INTO public.status (id_status, advanced) VALUES (6, 'Annulée');
INSERT INTO public.status (id_status, advanced) VALUES (7, 'Modifiée');


--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (26, 89, 'unit', 5, 1);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (27, 2000, 'cl', 5, 2);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (28, 3000, 'g', 5, 3);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (29, 27, 'unit', 5, 4);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (30, 1250, 'g', 5, 5);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (31, 78, 'unit', 6, 1);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (32, 3500, 'cl', 6, 2);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (33, 480, 'g', 6, 3);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (34, 7, 'unit', 6, 4);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (35, 800, 'g', 6, 5);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (36, 110, 'unit', 7, 1);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (37, 5500, 'cl', 7, 2);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (38, 4100, 'g', 7, 3);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (39, 53, 'unit', 7, 4);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (40, 1300, 'g', 7, 5);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (41, 96, 'unit', 8, 1);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (42, 1500, 'cl', 8, 2);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (43, 2100, 'g', 8, 3);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (44, 16, 'unit', 8, 4);
INSERT INTO public.stock (reference, quantity, unit, id_resto, id_ingredient) VALUES (45, 500, 'g', 8, 5);


--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_id_seq', 23, true);


--
-- Name: category_id_cat_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_id_cat_seq', 3, true);


--
-- Name: customer_num_client_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_num_client_seq', 4, true);


--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_id_seq', 14, true);


--
-- Name: ingredient_ref_prod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingredient_ref_prod_seq', 5, true);


--
-- Name: order_client_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_client_number_seq', 2, true);


--
-- Name: product_product_ref_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_product_ref_seq', 6, true);


--
-- Name: recipe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recipe_id_seq', 8, true);


--
-- Name: restaurant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.restaurant_id_seq', 8, true);


--
-- Name: role_id_job_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id_job_seq', 4, true);


--
-- Name: status_id_status_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_id_status_seq', 7, true);


--
-- Name: stock_reference_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_reference_seq', 45, true);


--
-- Name: address address_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pk PRIMARY KEY (id);


--
-- Name: category category_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pk PRIMARY KEY (id_cat);


--
-- Name: employee employee_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pk PRIMARY KEY (id);


--
-- Name: ingredient ingredient_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient
    ADD CONSTRAINT ingredient_pk PRIMARY KEY (id_ref);


--
-- Name: customer num_client_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT num_client_pk PRIMARY KEY (num_client);


--
-- Name: order_client order_client_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client
    ADD CONSTRAINT order_client_pk PRIMARY KEY (oder_num);


--
-- Name: product product_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pk PRIMARY KEY (product_ref);


--
-- Name: recipe recipe_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT recipe_pk PRIMARY KEY (id);


--
-- Name: restaurant resto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT resto_pk PRIMARY KEY (id);


--
-- Name: role role_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pk PRIMARY KEY (id_job);


--
-- Name: status status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pk PRIMARY KEY (id_status);


--
-- Name: stock stock_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pk PRIMARY KEY (reference);


--
-- Name: category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX category_idx ON public.category USING btree (name);


--
-- Name: ingredient_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ingredient_idx ON public.ingredient USING btree (name);


--
-- Name: order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX order_idx ON public.order_client USING btree (oder_num);


--
-- Name: product_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_idx ON public.product USING btree (name);


--
-- Name: restaurant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX restaurant_idx ON public.restaurant USING btree (name);


--
-- Name: role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX role_idx ON public.role USING btree (job_status);


--
-- Name: status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX status_idx ON public.status USING btree (advanced);


--
-- Name: employee address_employee_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT address_employee_fk FOREIGN KEY (id_address) REFERENCES public.address(id);


--
-- Name: order_client address_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client
    ADD CONSTRAINT address_order_fk FOREIGN KEY (id_address) REFERENCES public.address(id);


--
-- Name: restaurant address_restaurant_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT address_restaurant_fk FOREIGN KEY (id_address) REFERENCES public.address(id);


--
-- Name: product category_product_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT category_product_fk FOREIGN KEY (id_cat) REFERENCES public.category(id_cat);


--
-- Name: address customer_address_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT customer_address_fk FOREIGN KEY (num_client) REFERENCES public.customer(num_client);


--
-- Name: order_client customer_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client
    ADD CONSTRAINT customer_order_fk FOREIGN KEY (num_client) REFERENCES public.customer(num_client);


--
-- Name: order_client employee_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client
    ADD CONSTRAINT employee_order_fk FOREIGN KEY (id_employee) REFERENCES public.employee(id);


--
-- Name: recipe ingredient_recipe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT ingredient_recipe_fk FOREIGN KEY (id_ingredient) REFERENCES public.ingredient(id_ref);


--
-- Name: stock ingredient_stock_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT ingredient_stock_fk FOREIGN KEY (id_ingredient) REFERENCES public.ingredient(id_ref);


--
-- Name: order_line order_order_line_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line
    ADD CONSTRAINT order_order_line_fk FOREIGN KEY (order_num) REFERENCES public.order_client(oder_num);


--
-- Name: order_line product_order_line_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line
    ADD CONSTRAINT product_order_line_fk FOREIGN KEY (product_ref) REFERENCES public.product(product_ref);


--
-- Name: recipe product_recipe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT product_recipe_fk FOREIGN KEY (product_ref) REFERENCES public.product(product_ref);


--
-- Name: employee restaurant_employee_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT restaurant_employee_fk FOREIGN KEY (id_resto) REFERENCES public.restaurant(id);


--
-- Name: order_client restaurant_order_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client
    ADD CONSTRAINT restaurant_order_client_fk FOREIGN KEY (id_resto) REFERENCES public.restaurant(id);


--
-- Name: stock restaurant_stock_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT restaurant_stock_fk FOREIGN KEY (id_resto) REFERENCES public.restaurant(id);


--
-- Name: employee role_employee_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT role_employee_fk FOREIGN KEY (id_job) REFERENCES public.role(id_job);


--
-- Name: order_client status_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_client
    ADD CONSTRAINT status_order_fk FOREIGN KEY (id_status) REFERENCES public.status(id_status);


--
-- PostgreSQL database dump complete
--

